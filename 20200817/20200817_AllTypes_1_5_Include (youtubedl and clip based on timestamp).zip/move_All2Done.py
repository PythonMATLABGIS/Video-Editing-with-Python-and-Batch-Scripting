import os
import glob
import shutil
from datetime import datetime as dt
current_dir = os.getcwd()

def main():
#%%
	stime = dt.now()
#%% move the original wmv videos file into the backup folder after processing it
	#move_question = input('Do you want to move the original video into the backup folder(Y/N):')
	move_question = 'y'
	try: os.mkdir('Done')
	except: pass
	destination = os.path.join(current_dir,'Done')

	if move_question.upper() == 'Y':
		for f in glob.glob('*.wmv'):
			try: shutil.move(f,destination)
			except:
				raise RuntimeError("Can not move %s" % (f))

	print(50*'-')
	print('Total Processing time: %s' % (dt.now() - stime))
	#%%
if __name__ == "__main__":
	main()
