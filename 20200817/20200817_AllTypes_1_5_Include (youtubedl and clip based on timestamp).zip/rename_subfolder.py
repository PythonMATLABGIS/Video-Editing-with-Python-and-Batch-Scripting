import os
current_dir = os.getcwd()

def file_lst_ext_subfolder_filter(src_folder,filter_string="*"):
	'''
	list all files with extentions in a folder including subfolders using os.walk
	file_ext can be '*' or '.TIF' or '.ALL' named should be capitalised

	'''
	#Directory management
	root_p_lst = list()
	folder_p_lst = list()
	file_p_lst_full = list()
	for root, folders, filenames in os.walk(src_folder):
		root_p_lst.append(root)
		for folder in sorted(folders):
			folder_p_lst.append(str(os.path.join(root,folder)))
		for filename in sorted(filenames):
			file_p_lst_full.append(os.path.join(root,filename))
	file_p_lst = list()
	for f in file_p_lst_full:
		if filter_string == "*":
			return file_p_lst_full
		if filter_string.upper() in f.upper():
			file_p_lst.append(f)
		else: next  #pass or next here is better, probably pass?
	return file_p_lst


for idx,f in enumerate(file_lst_ext_subfolder_filter(current_dir,".ipynb")):
#	f = file_lst_ext_subfolder_filter(current_dir,".ipynb")[3]
	dir_name = os.path.dirname(f)
	f_name,f_ext = os.path.splitext(os.path.basename(f))
	temp_name = f_name.replace('XinhStyle','codeGIS')
	temp_name =temp_name.replace('XStyle','codeGIS')
	new_name = temp_name+f_ext
	new_path = os.path.join(dir_name,new_name)
	os.rename(f, new_path)
	print(idx,f_name)
	print(idx,new_name)