import datetime
import subprocess
import os
import glob
#import sys
#import time
from datetime import datetime as dt
from moviepy.editor import VideoFileClip
from pyVideoLib import *
current_dir = os.getcwd()

#list all file with extensions and sorted by datetime
def nameList_F_withExt_byTime(InputFolder,filterString="*"):
	os.chdir(InputFolder) #change working folder
	nameList = glob.glob(filterString)
	nameList.sort(key=os.path.getctime)
	return nameList

data_type = '*.mp4'

#make a list of file name
name_list = nameList_F_withExt_byTime(current_dir,data_type)
name_list.sort()

#sort by time and rename for upload
for idx,f in enumerate(name_list):
	# print(f)
	f_name,f_ext = os.path.splitext(f)
	temp_name = f_name.replace('__','_')
	temp_name =temp_name.replace('_',' ')
	temp_name =temp_name.replace('_',' ')
	temp_name =temp_name.replace(' .mp4','.mp4')
	new_name = temp_name+f_ext
	new_name =new_name.replace(' .mp4','.mp4')
	new_name =new_name.replace('_.mp4','.mp4')
	os.rename(f, new_name)

#make a list of file name and duration
duration_list = []
duration_list.append('00:00')

duration_accumulated = 0
for inFile in name_list:
#	inFile = name_list[0]
	inFile_duration_sec = clip_duration(inFile)
	duration_accumulated += inFile_duration_sec
	if duration_accumulated <= 3600:
		duration_youtubeFormat = get_strtime(duration_accumulated)[3:]
	else:
		duration_youtubeFormat = get_strtime(duration_accumulated)
	duration_list.append(duration_youtubeFormat)

duration_list.pop()

#Write to file
newfile = open('youtubeTimstamp.txt','w')
for i in zip(name_list,duration_list):
	duration = i[1]
	name = i[0]
	if name[:2].isdigit() and name[2].isalpha() and name[3].isdigit() and name[4] == ' ':
		name = name[2:]
		msg = '      ' + duration + ' ' + name[3:-4]
#		print(msg)
	elif name[:2].isdigit() and name[2].isalpha() and name[3] == ' ':
		name = name[1:]
		msg = '   ' + duration + ' ' + name[3:-4]
#		print(msg)
	else:
		msg = duration + ' ' + name[3:-4]
		# msg = '\n'+duration + ' ' + name[3:-4]
	print(msg)
	newfile.write(msg+'\n')
newfile.close()

