# -*- coding: utf-8 -*-

#%%
import datetime
import subprocess
import os
#import sys
#import time
from datetime import datetime as dt
from moviepy.editor import VideoFileClip
from pyVideoLib import *
current_dir = os.getcwd()
print(100*'#')
print(100*'-')
print(f' Working folder: {current_dir}')
print(50*'-')


###########################################

def main():

	sTime = dt.now()

	#merge
	print(50*'-')
	print(' Merge setup:')

	intro_file = 'codegis_intro.mp4'
	outtro_file = 'codegis_outtro.mp4'


	##Rename all the file
	for idx,f in enumerate(nameList_F_withExt(current_dir,'*.mp4')):
		# print(f)
		f_name,f_ext = os.path.splitext(f)
		temp_name = f_name.replace('  ',' ')
		temp_name = f_name.replace('  ',' ')
		temp_name =temp_name.replace(' ','_')
		temp_name =temp_name.replace('__','_')
		temp_name =temp_name.replace('__','_')
		new_name = temp_name+f_ext
		os.rename(f, new_name)
		print(new_name)

	##List All the file
	main_file_list = nameList_F_withExt(current_dir,'*.mp4')
	main_file_list.remove(intro_file)
	main_file_list.remove(outtro_file)
	for file in main_file_list:
		if '_io_merge_.mp4' in file:
			print(file)
			main_file_list.remove(file)
	for file in main_file_list:
		if '_io_merge_.mp4' in file:
			print(file)
			main_file_list.remove(file)


	##Create input merge text file for ffmpeg

	for file in main_file_list:
		#create a text file to merge laters
		input_file = open(file[:-4]+'_io_merge_.txt','w')
		msg = 'file '+ "'"+intro_file+"'"
		input_file.write(msg+'\n')
		msg = 'file '+ "'"+file+"'"
		input_file.write(msg+'\n')
		msg = 'file '+ "'"+outtro_file+"'"
		input_file.write(msg+'\n')
		input_file.close() #finish creating txt files


	try: os.mkdir('Merge_output')
	except: pass

	##merging
	print(50*'-')
	print(' Merge setup:')
	list_of_text_io_merge_file = nameList_F_withExt(current_dir,'*io_merge_.txt')
	if len(list_of_text_io_merge_file)==0:
		print(f'\tNo _2merge_ text file found, so nothing to merge')
	else:
		for inFile in list_of_text_io_merge_file:
#			inFile = list_of_text_io_merge_file[0]
			f_name,f_ext = inFile.split('.')
			outFile = 'Merge_output'+'/'+f_name+'.mp4'
			if os.path.exists(outFile):
				print(f'{outPath} is already existed')
			else:
				print(f'\tMerging inFile {inFile}')
				ffmpeg_merge_py(inFile,outFile)


	print(50*'-')
	print('Total Processing time: %s' % (dt.now() - sTime))
if __name__ == "__main__":
	main()