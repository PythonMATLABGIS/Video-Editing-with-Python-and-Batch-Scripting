# -*- coding: utf-8 -*-
"""
Created on Sat Mar 14 22:51:27 2020


@author: python MATLAB & GIS
"""
#%%
import datetime
import subprocess
import os
import re
import glob
#import sys
#import time
from datetime import datetime as dt
from moviepy.editor import VideoFileClip
from pyVideoLib import *
current_dir = os.getcwd()
print(100*'#')
print(100*'-')
print(f' Working folder: {current_dir}')
print(50*'-')
###########################################
def main():
	stime = dt.now()
	#-----------------------------------------------------------------------
	#general setup
	print(' General setup:')
	# margin = input('Margin: ')
	margin = 1
	# silent_threshold_pc = input('silent_threshold percent: ')
	silent_threshold_pc = 5
	jumpcut_suffix = 'jcmg'+str(margin)+'_'+str(silent_threshold_pc)+'pc'
	print(f'\t jumpcut_suffix: {jumpcut_suffix}')
	# duration_sec = input('duration_sec: ')
	duration_sec = 1200
	print(f'\t duration_sec =  {duration_sec}')
	#-----------------------------------------------------------------------
	#download setup
	print(50*'-')
	print(' Download setup:')
	#Download using youtube-dl
	# f = 22
	f = 'best'
	print(f'\t f =  {f}')
	download_yn = input('Download (Y/N)?:')
	# download_yn = 'N'
	print(f'\t download_yn =  {download_yn}')
	if download_yn.upper() == 'Y':
		inList = input('Youtube playlist to download:')
		try: youtubedl_pyrun(inList,f)
		except Exception as e:
			print(e)
			pass
	else:
		pass
#	inList = 'https://www.youtube.com/playlist?list=PLG19vXLQHvSC2ZKFIkgVpI9fCjkN38kwf'
	#youtubedl_pytest(inList)
#	try: youtubedl_pyrun(inList,f)
#	except Exception as e:
#		print(e)
#		pass
	#-----------------------------------------------------------------------
	#rename
	datatype_list = ['*.mp4','*.wmv','*.mov','*.avi','*.mkv']
	for data_type in datatype_list:
		for inFile in nameList_F_withExt(current_dir,data_type):
			rename_step1(inFile)

	for data_type in datatype_list:
		data_type_temp_file = open('data_type_temp_file_'+data_type[2:]+'.txt','w')
		for inFile in nameList_F_withExt(current_dir,data_type):
			inFile_duration = clip_duration(inFile)
			data_type_temp_file.write(inFile+','+str(inFile_duration)+'\n')
		data_type_temp_file.close()

	print(50*'-')
	print(' Rename setup:')
	# duration_sec = 1200
	duration_sec = int(duration_sec)
	print(f'\t duration_sec: {duration_sec} or {get_strtime(duration_sec)}')
	#	duration_sec = 30
	short_suffix = '_short_'
	print(f'\t short_suffix: {short_suffix}')
	long_suffix = '_long_'
	print(f'\t long_suffix: {long_suffix}')

	#-----------------------------------------------------------------------
	#split
	stime_split = dt.now()
	print(50*'-')
	print(' Split setup:')
	for data_type in datatype_list:
		for idx,inFile in enumerate(nameList_F_withExt(current_dir,data_type)):
			print(f'\t inFile: {inFile}')
			split_new(inFile,duration_sec,jumpcut_suffix,short_suffix,long_suffix)

	print('\tSplitting time: %s' % (dt.now() - stime_split))

	#-----------------------------------------------------------------------
	infile = open('Timestamp.txt','r')
	TimeStamp_Sec_lst = []
	TimeStamp_str_lst = []
	Title_lst = []
	for idx,line in enumerate(infile):
		line = line.strip('\n')
		line = line.replace('  ',' ')
		line = line.replace('  ',' ')
		if line == '' or line == ' ':
			next
#			print(idx,line,'skip')
		#if line = '0:00'
		else:
			if line[0].isdigit() and line[1]==':' and line[2].isdigit() and line[3].isdigit() and line[4]==' ':
				line = '00:0'+line
	#			print(idx,line)
	#			pass
			#if line = '00:00'
			elif line[0].isdigit() and line[1].isdigit() and line[2]==':' and line[3].isdigit() and line[4].isdigit() and line[5]==' ':
				line = '00:'+line
	#			print(line)
	#			pass
	#		if line = '0:00:00'
			elif line[0].isdigit() and line[1]==':' and line[2].isdigit() and line[3].isdigit() and line[4]==':' and line[5].isdigit() and line[6].isdigit() and line[7]==' ':
				line = '0'+line
	#			print(line)
	#			pass
	#		if line = '00:00:00'
			elif line[0].isdigit() and line[1].isdigit() and line[2]==':' and line[3].isdigit() and line[4].isdigit() and line[5]==':' and line[6].isdigit() and line[7].isdigit() and line[8]==' ':
	#			print(line)
				line = line
	#			pass
			print(idx,line)
			time_stamp = line[:8]
			TimeStamp_str_lst.append(time_stamp)
			TimeStamp_Sec_lst.append(get_sec(time_stamp))
			title = line[9:]
			Title_lst.append(title)

	clip_duration_list = []
	for i in range(0,len(Title_lst)-1):
		segment_start = TimeStamp_Sec_lst[i]
		segment_end = TimeStamp_Sec_lst[i+1]
		duration = segment_end - segment_start
		clip_duration_list.append(duration)
#		print(i+1,segment_start,get_strtime(segment_start),segment_end,get_strtime(segment_end),duration,get_strtime(duration))

	extention = input('Video extention(*.wmv, *.mp4):')
	inFile =glob.glob(extention)[0]
	# inFile = r'0Python_Object_Oriented_Programming_Example_for_Surveyors_and_GIS_Applications___Code_GIS_mECwHQ5kr6c.mp4'
	final_duration = clip_duration(inFile) - TimeStamp_Sec_lst[-1]
	clip_duration_list.append(final_duration)

	outfile_test = open('test_out.txt','w')
	for idx,line in enumerate(zip(TimeStamp_Sec_lst,clip_duration_list,Title_lst)):
#		print(idx,line)
		outFile = line[2]+'.mp4'
		start_point = line[0]
		duration_sec = line[1]
		msg = get_strtime(start_point)+'_'+get_strtime(duration_sec)+'_'+outFile
		print(msg)
		outfile_test.write(msg)
		ffmpeg_split(inFile,outFile,start_point,duration_sec)

	outfile_test.close()
	infile.close()

	print(50*'-')
	print('Total Processing time: %s' % (dt.now() - stime))
if __name__ == "__main__":
	main()
